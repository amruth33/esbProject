#ifndef CLIENT_H
#define CLIENT_H

int send_bmd_to_socket(char *msg,char *socket_file);

#endif