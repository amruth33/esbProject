#ifndef TRANSFORM_H
#define TRANSFORM_H

char * transformToJson(char *path);

#endif