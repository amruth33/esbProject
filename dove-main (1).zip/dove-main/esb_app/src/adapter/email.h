#ifndef EMAIL_H
#define EMAIL_H

int send_mail(char * to,char *buffer);

#endif