#ifndef HTTP_H
#define HTTP_H

int http(char *http_url,char *text);

#endif