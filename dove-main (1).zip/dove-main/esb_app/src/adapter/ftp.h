#ifndef FTP_H
#define FTP_H

int ftp(char *REMOTE_URL,char *LOCAL_FILE);

#endif